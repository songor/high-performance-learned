# Bootstrap TouchSpin

##### Bootstrap TouchSpin is a mobile and touch friendly input spinner component for Bootstrap 3.

- [Website](http://www.virtuosoft.eu/code/bootstrap-touchspin/)

Please report issues and feel free to make feature suggestions as well.

## License

Apache License, Version 2.0

[![githalytics.com alpha](https://cruel-carlota.pagodabox.com/73ffb6b38e5099909d7b13c577d7e5c8 "githalytics.com")](http://githalytics.com/istvan-ujjmeszaros/bootstrap-touchspin)
